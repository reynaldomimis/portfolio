export { default as Contact } from "./ContactScreens";
export { default as Main } from "./MainScreens";
export { default as Project } from "./ProjectScreens";
export { default as Specialization } from "./SpecializationScreens";
export { default as Testimonial } from "./TestimonialScreens";
